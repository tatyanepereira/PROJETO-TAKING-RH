package br.com.taking.filtrorestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiltroRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
